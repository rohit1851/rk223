const Anthropic = require("@anthropic-ai/sdk");

exports.handler = async (event) => {
  // Handle CORS preflight
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
      },
      body: "",
    };
  }

  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  // Rate limiting: check for required fields
  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid JSON" }) };
  }

  const { message, systemContext } = body;

  if (!message || typeof message !== "string" || message.length > 1000) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "Invalid message" }),
    };
  }

  if (!process.env.ANTHROPIC_API_KEY) {
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "AI service not configured. Add ANTHROPIC_API_KEY to Netlify environment variables.",
      }),
    };
  }

  try {
    const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

    const defaultSystem = `You are the Quantum X AI Advisor — a professional crypto investment assistant for the Quantum X platform (quantuminvestment.org).
Help users with: crypto market analysis, investment strategies, DeFi concepts, platform questions (deposits, withdrawals, plans), and portfolio advice.
Be concise, professional, and helpful. Tone: premium, confident, clear.
Plans: Silver ($500 min, up to 18% annual), Gold ($5K min, up to 34% annual), Obsidian ($50K min, up to 60% annual).
Wallets accepted: BTC, ETH, USDT (TRC-20).
Never provide financial guarantees. Always note crypto investments carry risk.`;

    const response = await client.messages.create({
      model: "claude-sonnet-4-20250514",
      max_tokens: 400,
      system: systemContext || defaultSystem,
      messages: [{ role: "user", content: message }],
    });

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ text: response.content[0].text }),
    };
  } catch (error) {
    console.error("AI proxy error:", error.message);
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: "AI service temporarily unavailable." }),
    };
  }
};
