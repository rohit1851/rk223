# QUANTUM X — Secure Deployment Guide
# quantuminvestment.org

=========================================================
 WHAT YOU HAVE
=========================================================
index.html              → Your full platform (frontend)
netlify.toml            → Netlify configuration & security headers  
netlify/functions/
  ai-proxy.js           → Secure AI backend (hides your API key)
  package.json          → Dependencies
schema.sql              → Database setup for Supabase
SETUP.md                → This file

=========================================================
 STEP 1 — SET UP FREE DATABASE (Supabase)
=========================================================

1. Go to https://supabase.com → Sign Up free

2. Click "New Project"
   - Name: quantumx
   - Database Password: (save this somewhere safe!)
   - Region: pick closest to you
   - Click "Create new project" → wait ~2 minutes

3. Go to SQL Editor (left sidebar) → "New Query"

4. Open the file "schema.sql" from this folder
   Copy ALL the content and paste it into Supabase SQL Editor
   Click "RUN" → you should see "Success"

5. Go to Project Settings → API
   Copy these two values — you'll need them soon:
   - Project URL  (looks like: https://xxxxx.supabase.co)
   - anon / public key  (long string starting with eyJ...)

6. Create your admin account:
   - Go to Authentication → Users → "Add user" → "Create new user"
   - Email: admin@quantuminvestment.org
   - Password: (choose a strong password — minimum 8 characters)
   - Click "Create User"
   - Copy the UUID shown (looks like: 550e8400-e29b-41d4-a716...)
   - Go back to SQL Editor → New Query → paste and run:
     UPDATE public.profiles 
     SET role='admin', status='active' 
     WHERE id='PASTE-YOUR-UUID-HERE';

=========================================================
 STEP 2 — EDIT index.html
=========================================================

Open index.html in any text editor (Notepad, TextEdit, VS Code)

Find these two lines near the top of the <script> section:
  const SUPABASE_URL  = 'YOUR_SUPABASE_URL';
  const SUPABASE_ANON = 'YOUR_SUPABASE_ANON_KEY';

Replace with your actual values from Step 1:
  const SUPABASE_URL  = 'https://xxxxx.supabase.co';
  const SUPABASE_ANON = 'eyJhbGc...your-long-key...';

Save the file.

=========================================================
 STEP 3 — DEPLOY TO NETLIFY
=========================================================

1. Go to https://netlify.com → Sign Up free

2. Click "Add new site" → "Deploy manually"

3. Drag and drop the ENTIRE "quantumx-secure" FOLDER
   (not just the index.html — drag the whole folder!)

4. Wait ~30 seconds → Netlify gives you a URL like:
   https://amazing-name-123.netlify.app

5. Test it — go to that URL and sign in with your admin credentials

=========================================================
 STEP 4 — ADD YOUR SECRET API KEY (AI Chat)
=========================================================

1. In Netlify → Site Settings → Environment Variables → "Add variable"

2. Add:
   Key:   ANTHROPIC_API_KEY
   Value: (your key from platform.openai.com or console.anthropic.com)

3. Go to Site Settings → Functions → check functions are deployed

4. In Netlify → Deploys → click "Trigger deploy" → "Deploy site"

=========================================================
 STEP 5 — CONNECT YOUR DOMAIN (quantuminvestment.org)
=========================================================

1. In Netlify → Site Settings → Domain Management → "Add custom domain"
   Type: quantuminvestment.org → Verify

2. Log into GoDaddy → My Products → quantuminvestment.org → DNS

3. Edit the A Record:
   - Type: A
   - Name: @
   - Value: 75.2.60.5
   - TTL: 600 seconds
   → Save

4. Add CNAME record:
   - Type: CNAME
   - Name: www
   - Value: your-netlify-site.netlify.app
   → Save

5. Back in Netlify → Domain Management → "Verify DNS configuration"

6. Netlify will auto-install your FREE SSL certificate within 10 minutes

7. Wait 10–30 minutes → visit quantuminvestment.org ✅

=========================================================
 STEP 6 — TEST EVERYTHING
=========================================================

□ Visit quantuminvestment.org — landing page loads
□ Sign in as admin — dashboard opens
□ Create a test customer account — gets pending status
□ Approve in admin panel — customer can now log in
□ Add a transaction — balance updates
□ Edit wallet address — updates for all users
□ AI chat — responds (needs ANTHROPIC_API_KEY set)
□ Submit inquiry form — appears in admin Inquiries tab
□ Site shows https:// padlock — SSL working

=========================================================
 SECURITY CHECKLIST
=========================================================

✅ Passwords hashed by Supabase (bcrypt) — never stored plain
✅ JWT tokens — sessions expire automatically  
✅ Row Level Security — users can only see their own data
✅ API key hidden — never exposed in browser code
✅ HTTPS enforced — all traffic encrypted
✅ Security headers — XSS, clickjacking protection
✅ Admin-only actions protected server-side
✅ Input validation on all forms

=========================================================
 NEED HELP?
=========================================================

Email: support@quantuminvestment.org
Supabase docs: https://supabase.com/docs
Netlify docs: https://docs.netlify.com
