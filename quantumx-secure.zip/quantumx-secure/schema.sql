-- ============================================================
-- QUANTUM X — Supabase Database Schema
-- Run this in: Supabase Dashboard → SQL Editor → New Query
-- ============================================================

-- 1. PROFILES (extends Supabase auth.users)
create table if not exists public.profiles (
  id uuid references auth.users(id) on delete cascade primary key,
  first_name text not null,
  last_name text not null,
  role text not null default 'user' check (role in ('admin', 'agent', 'support', 'user')),
  plan text not null default 'Silver' check (plan in ('Silver', 'Gold', 'Obsidian', 'None')),
  status text not null default 'pending' check (status in ('active', 'pending', 'suspended')),
  reason text,
  assigned_customers uuid[],
  joined_at timestamptz default now()
);

-- 2. TRANSACTIONS
create table if not exists public.transactions (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  type text not null check (type in ('deposit', 'withdrawal', 'profit', 'adjustment', 'bonus')),
  amount numeric(14,2) not null check (amount > 0),
  note text,
  wallet text,
  created_at timestamptz default now()
);

-- 3. WALLETS (platform deposit addresses)
create table if not exists public.wallets (
  id serial primary key,
  coin text not null,
  icon text,
  color text,
  network text,
  address text not null,
  updated_at timestamptz default now()
);

-- 4. INQUIRIES (from landing page contact form)
create table if not exists public.inquiries (
  id uuid default gen_random_uuid() primary key,
  first_name text,
  last_name text,
  email text,
  phone text,
  plan text,
  amount_range text,
  message text,
  is_read boolean default false,
  created_at timestamptz default now()
);

-- 5. TICKETS (customer support)
create table if not exists public.tickets (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade,
  subject text not null,
  message text not null,
  reply text,
  status text default 'open' check (status in ('open', 'pending', 'resolved')),
  created_at timestamptz default now()
);

-- ============================================================
-- SEED DEFAULT WALLETS
-- ============================================================
insert into public.wallets (coin, icon, color, network, address) values
  ('BTC',  '₿', '#F7931A', 'Bitcoin Network',    'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh'),
  ('ETH',  'Ξ', '#627EEA', 'ERC-20 (Ethereum)',  '0x71C7656EC7ab88b098defB751B7401B5f6d8976F'),
  ('USDT', '₮', '#26A17B', 'TRC-20 (TRON)',       'TRx8QDmXqsXP3iXpFbJkmHwXB4RQoBuUCk')
on conflict do nothing;

-- ============================================================
-- ROW LEVEL SECURITY (RLS) — This is what keeps data safe
-- ============================================================

alter table public.profiles    enable row level security;
alter table public.transactions enable row level security;
alter table public.wallets      enable row level security;
alter table public.inquiries    enable row level security;
alter table public.tickets      enable row level security;

-- Helper function: get current user's role
create or replace function public.get_my_role()
returns text language sql security definer
as $$ select role from public.profiles where id = auth.uid() $$;

-- ── PROFILES policies ──
create policy "Users view own profile"
  on public.profiles for select using (auth.uid() = id);

create policy "Staff view all profiles"
  on public.profiles for select
  using (public.get_my_role() in ('admin', 'agent', 'support'));

create policy "Admins manage all profiles"
  on public.profiles for all
  using (public.get_my_role() = 'admin');

create policy "Users update own profile"
  on public.profiles for update using (auth.uid() = id);

-- ── TRANSACTIONS policies ──
create policy "Users view own transactions"
  on public.transactions for select using (auth.uid() = user_id);

create policy "Staff view all transactions"
  on public.transactions for select
  using (public.get_my_role() in ('admin', 'agent'));

create policy "Admins and agents manage transactions"
  on public.transactions for all
  using (public.get_my_role() in ('admin', 'agent'));

-- ── WALLETS policies ──
create policy "Authenticated users view wallets"
  on public.wallets for select using (auth.role() = 'authenticated');

create policy "Admins manage wallets"
  on public.wallets for all
  using (public.get_my_role() = 'admin');

-- ── INQUIRIES policies ──
create policy "Anyone can insert inquiry"
  on public.inquiries for insert with check (true);

create policy "Admins view all inquiries"
  on public.inquiries for all
  using (public.get_my_role() in ('admin', 'support'));

-- ── TICKETS policies ──
create policy "Users view own tickets"
  on public.tickets for select using (auth.uid() = user_id);

create policy "Users create tickets"
  on public.tickets for insert with check (auth.uid() = user_id);

create policy "Staff manage all tickets"
  on public.tickets for all
  using (public.get_my_role() in ('admin', 'support', 'agent'));

-- ============================================================
-- AUTO-CREATE PROFILE ON SIGNUP (Supabase trigger)
-- ============================================================
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer
as $$
begin
  insert into public.profiles (id, first_name, last_name, plan, status, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'first_name', 'User'),
    coalesce(new.raw_user_meta_data->>'last_name', ''),
    coalesce(new.raw_user_meta_data->>'plan', 'Silver'),
    'pending',
    coalesce(new.raw_user_meta_data->>'role', 'user')
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ============================================================
-- CREATE ADMIN ACCOUNT
-- Go to Supabase → Authentication → Users → Add User
-- Email: admin@quantuminvestment.org
-- Then run this to make them admin:
-- UPDATE public.profiles SET role='admin', status='active' WHERE id='<paste-user-uuid-here>';
-- ============================================================
